<?php
$host="localhost";
$user="root";
$password="";
$db="student_project";
$dbcon=mysqli_connect("$host","$user","$password","$db");
?>