<?php
require 'db.php';


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <table border="1" cellspacing="0" width="800">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Dob</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>Join Date</th>
        <th>Delete</th>
      
    </tr>
<?php
$data_select=mysqli_query($dbcon,"SELECT * FROM `users`");
    while($rows=mysqli_fetch_assoc($data_select)){?>
    <tr>
        <td><?=$rows['id']?></td>
        <td><?=$rows['name']?></td>
        <td><?=$rows['dob']?></td>
        <td><?=$rows['email']?></td>
        <td><?=$rows['mobile']?></td>
        <td><?=$rows['join_date']?></td>
        <td><a target="blank" href="delete.php?id=<?=($rows['id'])?>">delete</a></td>

    </tr>
<?php
    }


?>

   </table> 
</body>
</html>