<?php
require 'db.php';
$target_id=$_GET['id'];
$delete_query=mysqli_query($dbcon,"DELETE FROM `users` WHERE `id`='$target_id'");
if($delete_query){
	echo '
		<script>
		window.alert("Successfully Deleted data");
		window.location.href="all_users.php";
		</script>
	';
}

?>